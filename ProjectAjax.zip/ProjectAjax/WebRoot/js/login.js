$(function(){
	login();
})

function login(){
	$("#login").bind("click",function(){
		var name=$("#name").val();
		var pwd=$("#pwd").val();
		$.post("servlet/UserServlet?type=getUser",{"name":name,"pwd":pwd},function(data){
				if(data==1)
					location.href="list.html";
				else
					alert("�û������������");
			})
	})
}