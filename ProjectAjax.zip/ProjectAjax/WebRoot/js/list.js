$(function(){
	loadList(1,10);
	loadPagination(10);
})
//��ҳ����
function loadList(pageIndex,pageSize){
	$.getJSON("servlet/UserServlet?type=getUserPage",{"pageIndex":pageIndex,"pageSize":pageSize},function(data){
			var tab=$("#tab1");
			tab.html("");
			var msg="";
			for(var i=0;i<data.length;i++){
				msg+="<tr>"
				msg+="<td>"+data[i].id+"</td>"
				msg+="<td>"+data[i].name+"</td>"
				msg+="<td>"+data[i].pwd+"</td>"
				msg+="<td>"+data[i].rinfo.name+"</td>"
				msg+="<td><a href='javascript:deleteUser("+data[i].id+")'>ɾ��</a>&nbsp;&nbsp<a href='javascript:updateUser("+data[i].id+")'>�޸�</a></td>"
				msg+="</tr>"
			}
			$("#tab1").html(tab.html()+msg);
	})
}
//������Ϣ
function updateUser(id){	
	$("#update").show();
		$("#but1").bind("click",function(){
			$.getJSON("servlet/UserServlet?type=updateUser",{"id":id,"name":$("#name").val(),"pwd":$("#pwd").val()},function(data){
				$("#update").hide();
			})
		})
}
//ɾ����Ϣ
function deleteUser(id){
	$.get("servlet/UserServlet?type=deleteUser",{"id":id},function(){
		var submit = function (v, h, f) {
		    if (v){
		        jBox.tip("YES", 'info');
		    	
		    }
		    else
		        jBox.tip("NO", 'info');
		    return true;
		};
		// �Զ��尴ť
		$.jBox.confirm("�Ƿ�ȷ��ɾ������", "ϵͳ��ʾ", submit, { buttons: { 'YES': true, 'NO': false} });	
	})
}
//��ҳ����
function loadPagination(pageSize){
	$.get("servlet/UserServlet?type=getCount",{"pageSize":pageSize},function(data){
		var Pager = new Pagination({
		    parent: '#div2',
		    totalPage: data,
		    prevText:"Prev",
		    nextText:"Next",
		    pageSize:5
		
	});

	Pager.on('afterChange', function(args){
		var index=args.currentPage
		loadList(index,10);
	})	
		
	});
}