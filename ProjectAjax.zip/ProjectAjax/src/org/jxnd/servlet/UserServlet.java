package org.jxnd.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jxnd.bean.UserInfo;
import org.jxnd.service.IUserService;
import org.jxnd.service.impl.UserServiceImpl;

import com.google.gson.Gson;

public class UserServlet extends HttpServlet {
	IUserService service=new UserServiceImpl();
	Gson gson=new Gson();
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("UTF-8");
		String type=request.getParameter("type");
		try {
			Method mt=UserServlet.class.getMethod(type, HttpServletRequest.class,HttpServletResponse.class);
			
				mt.invoke(this, request,response);
			} catch (Exception e) {
		}
	}
	public void getUserByName(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		String name =request.getParameter("name"); 
		if(service.getUserByName(name))
			response.getWriter().print("1");
		else
			response.getWriter().print("2");
			
	}
	public void updateUser(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		int id=request.getParameter("id")==null?0:Integer.parseInt(request.getParameter("id").toString());
		String name=request.getParameter("name");
		String pwd=request.getParameter("pwd");
		UserInfo info=null;
		if(service.updateUser(name,pwd,id)){
			info.setName(name);
			info.setPwd(pwd);
			info.setId(id);
			String msg=gson.toJson(info);
			response.getWriter().print(msg);
		}
	}
	
	public void deleteUser(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		int id=request.getParameter("id")==null?0:Integer.parseInt(request.getParameter("id").toString());
		if(service.deleteUser(id))
			response.getWriter().print("1");
		else
			response.getWriter().print("2");
	}
	public void getCount(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		int pageSize=request.getParameter("pageSize")==null?10:Integer.parseInt(request.getParameter("pageSize"));
		int count=service.getCount();
		int data= (int) Math.ceil(count/pageSize);
		response.getWriter().print(data);
	}
	public void getUserPage(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException{
		int pageIndex=request.getParameter("pageIndex")==null?1:Integer.parseInt(request.getParameter("pageIndex"));
		int pageSize=request.getParameter("pageSize")==null?10:Integer.parseInt(request.getParameter("pageSize"));
		List<UserInfo> list=service.getUserPage(pageIndex, pageSize);
		if(list!=null&&list.size()>0){
			String msg=gson.toJson(list);
			response.getWriter().print(msg);
		}else
			response.getWriter().print("1");
		response.getWriter().flush();
	}
	public void getUser(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		String name=request.getParameter("name");
		String pwd=request.getParameter("pwd");
		UserInfo info=service.getUser(name, pwd);
		if(info!=null){
			request.getSession().setAttribute("info", info);
			response.getWriter().print("1");
		}	
		else
			response.getWriter().print("2");
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doGet(request, response);
	}

}
