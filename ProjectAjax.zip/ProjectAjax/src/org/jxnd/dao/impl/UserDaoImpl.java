package org.jxnd.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.jxnd.bean.UserInfo;
import org.jxnd.dao.IUserDao;
import org.jxnd.tools.DBTools;

public class UserDaoImpl implements IUserDao{
	public boolean getUserByName(String name){
		String sql="select * from userinfo where name=?";
		List<Object> list=new ArrayList<Object>();
		list.add(name);
		ResultSet rs=DBTools.getReusultSet(sql,list);
		try {
			if(rs.next()){
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			DBTools.close();
		}
		return false;
	}

	@Override
	public UserInfo getUser(String name, String pwd) {
		UserInfo info=null;
		String sql="select * from userinfo where name=? and pwd=?";
		List<Object> plist=new ArrayList<Object>();
		plist.add(name);
		plist.add(pwd);
		ResultSet rs=DBTools.getReusultSet(sql, plist);
		try {
			if(rs.next()){
				info=new UserInfo();
				info.setName(rs.getString("name"));
				info.setPwd(rs.getString("pwd"));
				return info;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return info;
	}

	@Override
	public List<UserInfo> getUserPage(int pageIndex, int pageSize) {
		String sql="select * from (select rownum as r_id,userinfo.id as userinfo_id,userinfo.name as userinfo_name,userinfo.pwd as userinfo_pwd,userinfo.rolesid as userinfo_rolesid,roles.id as roles_id,roles.name as roles_name from userinfo,roles where userinfo.rolesid=roles.id) where r_id>? and r_id<?";
		List<Object> plist=new ArrayList<Object>();
		plist.add((pageIndex-1)*pageSize);
		plist.add(pageIndex*pageSize+1);
		return DBTools.getListBySql(UserInfo.class, sql, plist);
	}

	@Override
	public int getCount() {
		int i=0;
		String sql="select count(*) as count from userinfo";
		ResultSet rs=DBTools.getReusultSet(sql);
		try {
			if(rs.next()){
				i=rs.getInt("count");
			}
			return i;
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			DBTools.close();
		}
		return i;
	}

	@Override
	public int deleteUser(int id) {
		int i= DBTools.deleteObject(UserInfo.class, id);
		return i;
	}

	@Override
	public boolean updateUser(String name,String pwd,int id) {
		int i=0;
		String sql="update userinfo set name=?,pwd=? where id=?";
		List<Object> list=new ArrayList<Object>();
		list.add(name);
		list.add(pwd);
		list.add(id);
		ResultSet rs= DBTools.getReusultSet(sql, list);
		try {
			if(rs.next()){
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
}
