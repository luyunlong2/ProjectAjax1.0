package org.jxnd.bean;

public class UserInfo {
	private int id;
	private String name;
	private String pwd;
	private int rolesid;
	private Roles rinfo;
	public UserInfo(int id,String name,String pwd,int rolesid,Roles info){
		super();
		this.id=id;
		this.name=name;
		this.pwd=pwd;
		this.rolesid=rolesid;
		this.rinfo=rinfo;
	}
	public UserInfo(){}
	public void setId(int id){
		this.id=id;
	}
	public void setName(String name){
		this.name=name;
	}
	public void setPwd(String pwd){
		this.pwd=pwd;
	}
	public void setRolesId(int rolesid){
		this.rolesid=rolesid;
	}
	public int getId(){
		return this.id;
	}
	public String getName(){
		return this.name;
	}
	public String getPwd(){
		return this.pwd;
	}
	public int getRolesid(){
		return this.rolesid;
	}
	public String toString(){
		return name;
	}
	public void setRinfo(Roles rinfo){
		this.rinfo=rinfo;
	}
	public Roles getRinfo(){
		return this.rinfo;
	}
}
