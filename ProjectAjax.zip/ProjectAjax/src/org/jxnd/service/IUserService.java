package org.jxnd.service;


import java.util.List;

import org.jxnd.bean.UserInfo;

public interface IUserService {
	public boolean getUserByName(String name);
	public UserInfo getUser(String name,String pwd);
	public List<UserInfo> getUserPage(int pageIndex,int pageSize);
	public int getCount();
	public boolean deleteUser(int i);
	public boolean updateUser(String name,String pwd,int id);
}
