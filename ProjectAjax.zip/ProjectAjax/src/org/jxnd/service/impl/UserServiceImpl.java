package org.jxnd.service.impl;

import java.sql.ResultSet;
import java.util.List;

import org.jxnd.bean.UserInfo;
import org.jxnd.dao.IUserDao;
import org.jxnd.dao.impl.UserDaoImpl;
import org.jxnd.service.IUserService;

public class UserServiceImpl implements IUserService {
	IUserDao dao=new UserDaoImpl();
	@Override
	public boolean getUserByName(String name) {
		return dao.getUserByName(name);
	}
	@Override
	public UserInfo getUser(String name, String pwd) {
		return dao.getUser(name, pwd);
	}
	@Override
	public List<UserInfo> getUserPage(int pageIndex, int pageSize) {
		return dao.getUserPage(pageIndex, pageSize);
	}
	@Override
	public int getCount() {
		return dao.getCount();
	}
	@Override
	public boolean deleteUser(int id) {
		return dao.deleteUser(id)>0;
	}
	@Override
	public boolean updateUser(String name,String pwd,int id) {
		return dao.updateUser(name,pwd,id);
	}

}
